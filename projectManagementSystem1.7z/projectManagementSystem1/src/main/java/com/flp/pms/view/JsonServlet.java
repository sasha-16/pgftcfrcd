package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

/**
 * Servlet implementation class Controller
 */
public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		PrintWriter out=response.getWriter();
		IProductService iProductService=new ProductServiceImpl();
		Gson myjson=new Gson();
		if(action.equalsIgnoreCase("category")){
		response.setContentType("application/json");
		List<Category> categories=iProductService.getAllCategory();
		
		String catjson=myjson.toJson(categories);
		out.println(catjson);
		}
		else if(action.equalsIgnoreCase("supplier")){
			response.setContentType("application/json");
			List<Supplier> suppliers=iProductService.getAllSuppliers();
			String supjson=myjson.toJson(suppliers);
			out.println(supjson);
		}
		else if(action.equalsIgnoreCase("subcategory")){
			response.setContentType("application/json");
			List<SubCategory> subCategories=iProductService.getAllSubCategory();
			String subcatjson=myjson.toJson(subCategories);
			out.println(subcatjson);
		}
		else if(action.equalsIgnoreCase("discount")){
			response.setContentType("application/json");
			List<Discount> discounts=iProductService.getAllDiscounts();
			String disjson=myjson.toJson(discounts);
			out.println(disjson);
		}
		else if(action.equalsIgnoreCase("ProductList")){
			response.setContentType("application/json");
			List<Product> products=iProductService.viewAllProductList();
			String productList=myjson.toJson(products);
			out.println(productList);
		}
	}

}
